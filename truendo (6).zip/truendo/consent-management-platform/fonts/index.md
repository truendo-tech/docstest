---
# snazzyDocs - DO NOT REMOVE OR EDIT BELOW THIS LINE
title: Index
id: L64-MB65-6R7-FTF
slug: index
isVisible: true
lastUpdated: '2024-03-19 13:32:35'
---
# <span class="text-large">TRUENDO'S Fonts</span>

TRUENDO uses fonts that are hosted by TRUENDO and not external font services.

TRUENDO uses Roboto as its font-family

TRUENDO allows you to disable Roboto as the font-family.<br />

<br />

## How to disable TRUENDO'S font.

<span class="text-large">You can disable it by adding the following attribute to the script:</span>

```
data-nofont="true"
```

The script tag should now look like this

```
<!-- TRUENDO Privacy Center -->
<script id="truendoAutoBlock" type="text/javascript" src="https://cdn.priv.center/pc/truendo_cmp.pid.js" data-nofont="true" data-siteid="YOUR SITE ID"></script>
<!-- End TRUENDO Privacy Center -->
```

<br />