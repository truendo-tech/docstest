---
# snazzyDocs - DO NOT REMOVE OR EDIT BELOW THIS LINE
title: 'Consent Records'
id: 9AT-VZUB-98P-KGZ
slug: consent-records
isVisible: true
lastUpdated: '2023-03-30 13:54:09'
---
# **<span style="color:rgb(26, 26, 26) !important;"><span style="background-color:rgb(255, 255, 255);">Consent Records</span></span>**

**<span style="color:rgb(10, 10, 10);"><span style="background-color:rgb(255, 255, 255);">Premium </span></span>** <span style="color:rgb(10, 10, 10);"><span style="background-color:rgb(255, 255, 255);">users can find all information related to their consent records in the </span></span> **<span style="color:rgb(10, 10, 10);"><span style="background-color:rgb(255, 255, 255);">Consents</span></span>** <span style="color:rgb(10, 10, 10);"><span style="background-color:rgb(255, 255, 255);"> section in the main navigation menu.</span></span>

<br />

<iframe src="https://www.youtube.com/embed/SmuTdUwEv7s?showinfo=0" frameborder="0" allowfullscreen="true" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" width="100%"></iframe>

<br />