---
# snazzyDocs - DO NOT REMOVE OR EDIT BELOW THIS LINE
title: 'Billing Details'
id: PW6-BRI9-2T3-I6B
slug: billing-details
isVisible: true
lastUpdated: '2023-11-27 07:38:24'
---
# <span style="color:rgb(0, 0, 0);"><span style="background-color:rgb(255, 255, 255);">Billing Details</span></span>

### <span style="color:rgb(0, 0, 0);"><span style="background-color:rgb(255, 255, 255);">Step 1</span></span>

<span style="color:rgb(0, 0, 0);"><span style="background-color:rgb(255, 255, 255);">Once logged in, click the drop down next to your organization name on the top of the window and then click </span></span> **<span style="color:rgb(0, 0, 0);"><span style="background-color:rgb(255, 255, 255);">Manage</span></span>**<span style="color:rgb(0, 0, 0);"><span style="background-color:rgb(255, 255, 255);">. You are now on the organization overview page.</span></span>

### <span style="color:rgb(0, 0, 0);"><span style="background-color:rgb(255, 255, 255);">Step 2</span></span>

<span style="color:rgb(0, 0, 0);"><span style="background-color:rgb(255, 255, 255);">Click </span></span> **<span style="color:rgb(0, 0, 0);"><span style="background-color:rgb(255, 255, 255);">Organization Details </span></span>** <span style="color:rgb(0, 0, 0);"><span style="background-color:rgb(255, 255, 255);">in the menu the left of the screen.</span></span>

### <span style="color:rgb(0, 0, 0);"><span style="background-color:rgb(255, 255, 255);">Step 3</span></span>

You may now enter and edit your billing information (address, credit card, email)

<br />

<div class="sd-callout" data-callout-type="alert">Please ensure you save any changes made in order for them to be in effect.</div>

<br />