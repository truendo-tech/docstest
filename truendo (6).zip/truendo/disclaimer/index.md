---
# snazzyDocs - DO NOT REMOVE OR EDIT BELOW THIS LINE
title: Index
id: B4J-YPHJ-ZOJ-VI8
slug: index
isVisible: true
lastUpdated: '2023-02-14 07:20:00'
---
# Disclaimer

<br />

<span style="color:rgb(0, 0, 0);"><span style="background-color:rgb(255, 255, 255);"><span align="left">TRUENDO is a Consent Management Platform with an integrated Privacy Policy and Cookie Policy. It is a website privacy solution for GDPR and CCPA compliance. However, there are many aspects of the GDPR an organization needs to cover, website compliance is only one of these things. The implementation of a data protection law compliant Consent Management Platform (CMP) is ultimately at the discretion of the respective data protection officer (DPO) or legal department. To ensure your organization is fully compliant and up to date with the latest regulations, or to learn more about the other aspects to being GDPR compliant, such as creating a data inventory, conducting Data Protection Impact Assessments (DPIA), or implementing a system to handle large amounts of Data Subject Access Requests (DSAR), we advise that you seek legal counsel.</span></span></span>