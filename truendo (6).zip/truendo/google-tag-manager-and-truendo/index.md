---
# snazzyDocs - DO NOT REMOVE OR EDIT BELOW THIS LINE
title: Index
id: SAL-PF6J-EMH-GQE
slug: index
isVisible: true
lastUpdated: '2024-05-23 09:51:57'
---
# Google Tag Manager (GTM) and TRUENDO

The contents on this chapter are for those who wish to integrate TRUENDO via Google Tag Manager (GTM)

<div class="sd-callout" data-callout-type="alert">Before proceeding please <strong>remove/deactivate any existing scripts/plugins you may have previously used to integrate TRUENDO</strong> on your website. Google Tag manager will do it automatically once the procedure below is completed.</div>

<br />